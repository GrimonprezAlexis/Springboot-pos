export interface UserEntity {
  _id: string;
  _name: string;
  _userName: string;
  _phoneNumber: string;
  _userPicture: string;
  _activationStatus: boolean;
}
