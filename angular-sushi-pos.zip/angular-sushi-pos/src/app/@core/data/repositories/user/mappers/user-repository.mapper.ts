import { Mapper } from '@/app/@core/base/mapper';
import { UserModel } from '@/app/@core/domain/models/user.model';
import { UserEntity } from '../entities/user-entity';

export class UserImplementationRepositoryMapper extends Mapper<
  UserEntity,
  UserModel
> {
  mapFrom(param: UserEntity): UserModel {
    return {
      id: param._id,
      fullName: param._name,
      username: param._userName,
      phoneNum: param._phoneNumber,
      profilePicture: param._userPicture,
      activationStatus: param._activationStatus,
    };
  }
  mapTo(param: UserModel): UserEntity {
    return {
      _id: param.id,
      _name: param.fullName,
      _userName: param.username,
      _phoneNumber: param.phoneNum,
      _userPicture: param.profilePicture,
      _activationStatus: param.activationStatus,
    };
  }
}
