# java-springboot-pos

Prequis
`https://maven.apache.org/download.cgi
https://www.oracle.com/java/technologies/javase-jdk11-downloads.html
https://www.postgresql.org/download/
https://www.postman.com/downloads/`


src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── example/
│   │           └── demo/
│   │               ├── DemoApplication.java
│   │               ├── config/
│   │               ├── controller/
│   │               │   ├── UserController.java
│   │               ├── domain/
│   │               │   ├── model/
│   │               │   │   ├── User.java
│   │               │   ├── repository/
│   │               │   │   ├── UserRepository.java
│   │               │   ├── service/
│   │               │   │   ├── UserService.java
│   │               ├── infrastructure/
│   │               │   ├── entity/
│   │               │   │   ├── UserEntity.java
│   │               │   ├── mapper/
│   │               │   │   ├── UserMapper.java
│   │               │   ├── repository/
│   │               │   │   ├── UserRepositoryImpl.java
│   │               │   │   ├── JpaUserRepository.java
│   │               ├── security/
│   │               │   ├── SecurityConfig.java
│   ├── resources/
│   │   ├── application.properties
