package com.example.demo.infrastructure.entity;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long _id;
    private String _username;
    private String _password;
    private String _role;

    // Getters et setters
}
