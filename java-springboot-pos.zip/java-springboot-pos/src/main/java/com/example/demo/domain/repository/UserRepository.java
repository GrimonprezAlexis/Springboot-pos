package com.example.demo.domain.repository;

import com.example.demo.domain.model.User;
import java.util.Optional;

public interface UserRepository {
    Optional<User> findByUsername(String _username);
    User save(User user);
}
