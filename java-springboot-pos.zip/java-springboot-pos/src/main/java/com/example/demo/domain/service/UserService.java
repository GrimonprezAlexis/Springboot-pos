package com.example.demo.domain.service;

import com.example.demo.domain.model.User;
import com.example.demo.domain.repository.UserRepository;
import java.util.Optional;

public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Optional<User> findByUsername(String _username) {
        return userRepository.findByUsername(_username);
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }
}
