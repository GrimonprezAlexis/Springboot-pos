package com.example.demo.domain.model;

public class User {
    private Long _id;
    private String _username;
    private String _password;
    private String _role;

    // Getters et setters
}
